# Negar Sadeghian — Portfolio

Personal portfolio of Negar Sadeghian, Product Designer.

A single-file static site (`index.html`) with hash-based routing: Projects, Experiments, Showcase, About and Resume.

## Run locally
Open `index.html` in a browser.

## Deploy with GitHub Pages
Repo Settings → Pages → Source: `main` branch, `/ (root)`.
